def ReverseElements(arr):
    #input::: array of numbers
    #output::: array of numbers in descending order
    #time-complexity::: O(n)
    #Purporse::: O(n) test function
    arr.reverse()
    return arr