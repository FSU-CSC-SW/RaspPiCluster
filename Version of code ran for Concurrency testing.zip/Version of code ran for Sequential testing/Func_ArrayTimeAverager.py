def avgOfArray(arr):
    summ = 0
    counter = 0
    for x in arr:
        summ += x
        counter += 1
    return summ/counter